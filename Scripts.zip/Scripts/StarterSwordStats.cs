using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StarterSwordStats : MonoBehaviour
{
    public int damage = 5;
    public int acccuracy = 50;

    
}
