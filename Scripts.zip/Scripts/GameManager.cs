using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    // add booleans for objects that the player can pickup.

    public bool prisonKey; // checks if starting area prison key was picked up.

    // checks for which weapon is active

    public enum equipedWeapon
    {
        starterWeapon,

    }

}
